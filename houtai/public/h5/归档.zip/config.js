window.config = {
    // api: 'https://ok77168.space/index/', //第二客户
    // api: 'https://amza.info/index', //第二客户
    // api: 'http://sc12.com/index', //第二客户
    // api: 'http://143.92.51.174:3102/index', //第二客户
    api: '/vi', //第二客户
}